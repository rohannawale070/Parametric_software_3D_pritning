-- %%%%%% PARAMETRIC SHAFT %%%%%%

-- r = Rolling circle radius
-- z = Number of lobes
-- n = Number of support points
-- R = Base circle radius
-- a = Center distance
-- XY = Table of vectors

function shaft(r_shaft,n) -- This function takes r_shaft and n as bore diameter and support points respectively to calculate the shaft. The table of vectors XY is output of the function and used to emit shape.
  XY = {}
  b=360/n
  for i=0,n, 1
  do
    XY[i] = v(r_shaft*cos(b),r_shaft*sin(b))
    b=b+360/n
  end
  XY[n+1]= XY[1]
  return XY
end

--%%%%%%%%%% Inputs %%%%%%%%%%%%
r=ui_numberBox("Rolling circle radius", 15)
z_list = {{2, "2"},{3, "3"},{4, "4"},{5, "5"}}
z = ui_radio("Number of lobes", z_list)
R=2*r*z
a = 2*R
t = 80
n = 100
dir = v(0,0,t) 
r_shaft = r*z*0.7
len_shaft = ui_numberBox("length of shaft", 136)

--%%%%%%%%%%% Shaft %%%%%%%%%%%%

XY=shaft(r_shaft,n)
dir_shaft = v(0,0,-len_shaft)
shaft = linear_extrude(dir_shaft,XY)
emit(shaft)
emit(translate(-a,0,0)*shaft) 