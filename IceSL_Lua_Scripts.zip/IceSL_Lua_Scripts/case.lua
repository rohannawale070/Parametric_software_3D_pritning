-- %%%%%% PARAMETRIC CASING %%%%%%

-- r = Rolling circle radius
-- z = Number of lobes
-- n = Number of support points
-- R = Base circle radius
-- Rv = Radius of pump casing
-- a = Center distance
-- t = Impeller thickness
-- XY1 = Table of vectors

function casing(r,n) -- This function takes r and n to calculate the casing profile. The table of vectors XY is output of the function and used to emit shape.
  m1=tan(0)
  R=2*z*r -- centre distance/2
  Rv = R+(2*r) --casing curvature
  x2=-R
  x=R
  theta=90
  theta_2=270;
  XY = {} 
  for i=1,n, 1
  do
    XY[i]=v(x,m1*x+Rv) --straight line eq
    XY[i]=v(x2,m1*x2-Rv)
    XY[i]=v(-R+(Rv)*cos(theta),(Rv)*sin(theta)) -- curvature equation
    XY[i+n]=v(R+(Rv)*cos(theta_2),(Rv)*sin(theta_2))
    x=x-n
    x2=x2+n
    theta=theta+180/n
    theta_2=theta_2+180/n
  end
  return XY
end

function bore(r_bore,n) -- This function takes r_bore and n as bore diameter and support points respectively to calculate the reference hole for the drilling convinience. The table of vectors XY is output of the function and used to emit shape.
  XY = {}
  b=360/n
  for i=0,100, 1
  do
    XY[i] = v(r_bore*cos(b),r_bore*sin(b))
    b=b+360/n
  end
  XY[n+1]= XY[1]
  return XY
end

--%%%%%%%%%%% Input %%%%%%%%%%%%%
r=ui_numberBox("Rolling circle radius", 15)
z_list = {{2, "2"},{3, "3"},{4, "4"},{5, "5"}}
z = ui_radio("Number of lobes", z_list)
R=2*r*z
a = 2*R
t = ui_numberBox("impeller thickness", 80)
n = 100
dir = v(0,0,t) 
r_bore = r*z*0.1

--%%%%%%%%%%% Casing %%%%%%%%%%%%%%%

XY = casing(r,n)
case0 = linear_extrude(dir,XY)
case1 = translate(0,0,2)*case0
case2 = translate(0,0,-2)*scale(1.1,1.2,1)*case0
s1 = translate(-a/2,0,0)*difference(case2,case1) --casing shape

--%%%%%%%%%%% Bore %%%%%%%%%%%%%%%
XY=bore(r_bore,n)
bore = linear_extrude(dir,XY)
bore1 = translate(0,0,-2)*bore
bore2 = translate(-a,0,-2)*bore
s2 = union(bore1,bore2)
emit(difference(s1,s2),7) 
--casing and hole difference is emitted
