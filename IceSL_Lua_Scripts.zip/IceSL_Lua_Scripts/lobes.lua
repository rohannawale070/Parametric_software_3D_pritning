-- %%%%%% PARAMETRIC LOBE PROFILE %%%%%%

-- r = Rolling circle radius
-- z = Number of lobes
-- n = Number of support points
-- R = Base circle radius
-- a = Center distance
-- t = Impeller thickness
-- XY = Table of vectors
-- ang_lobe = Angle between lobes
-- Variables: (static_var,dyn_var)

function lobeprofile(r,z) --used with linear extrude to build a lobe shape. -- This function takes r and z as bore diameter and no. of teeth respectively to calculate the reference lobe profile. The table of vectors XY is output of the function and used to emit shape.
  ang_lobe = 180/z
  static_var = ang_lobe
  XY = {}
  dyn_var = 0
  for i = 1, z, 1 
  do
    for phi = dyn_var, ang_lobe, 1
    do
      XY[phi]=v(-r*cos((2*z+1)*phi)+r*(2*z+1)*cos(phi),-r*sin((2*z+1)*phi)+r*(2*z+1)*sin(phi)) -- Epicycloid equation is running through loop for the number of lobes according to ang_lobe
    end
    for phi = ang_lobe, ang_lobe + static_var, 1
    do
      XY[phi]=v(r*cos((2*z-1)*phi)+r*(2*z-1)*cos(phi),-r*sin((2*z-1)*phi)+r*(2*z-1)*sin(phi)) -- Hypocycloid equation is running through loop for the number of lobes according to ang_lobe
    end
    dyn_var = ang_lobe + static_var
    ang_lobe = dyn_var + static_var
  end
  XY[z+1]= XY[1]
  return XY
end

--%%%%%%%%%%% Input %%%%%%%%%%%%%
r=ui_numberBox("Rolling circle radius", 15)
z_list = {{2, "2"},{3, "3"},{4, "4"},{5, "5"}}
z = ui_radio("Number of lobes", z_list)
R=2*r*z
a = 2*R
t = ui_numberBox("impeller thickness", 80)
n = 100
dir = v(0,0,t) --the thickness in z direction
r_bore = r*z*0.7
show3 = math.floor(ui_scalar('rotate my lobes',0,0,360)) -- for the rendering of the lobes and gear

--%%%%%%%%%%% Lobe %%%%%%%%%%%%%

XY=lobeprofile(r,z)
lobe = linear_extrude(dir,XY)
s1 = translate(0,0,0)*lobe
emit(translate(0,0,0)*rotate(0,0,show3)*s1,4) -- lobe shape emmitted