-- %%%%%% PARAMETRIC GEAR %%%%%%

-- r = Rolling circle radius
-- z = Number of lobes
-- z_gear = Number of teeth on gear
-- n = Number of support points
-- R = Base circle radius
-- a = Center distance
-- t_gear = Gear thickness
-- XY = Table of vectors

function bore(r_bore,n) -- This function takes r_bore and n as bore diameter and support points respectively to calculate the reference hole for the drilling convinience. The table of vectors XY is output of the function and used to emit shape.
  XY = {}
  b=360/n
  for i=0,100, 1
  do
    XY[i] = v(r_bore*cos(b),r_bore*sin(b))
    b=b+360/n
  end
  XY[n+1]= XY[1]
  return XY
end
--%%%%%%%%%% Inputs %%%%%%%%%%%%%%
r=ui_numberBox("Rolling circle radius", 15)
z_list = {{2, "2"},{3, "3"},{4, "4"},{5, "5"}}
z = ui_radio("Number of lobes", z_list)
R=2*r*z
a = 2*R
t = 80
n = 100
dir = v(0,0,t) 
r_bore = r*z*0.1
t_gear=ui_numberBox("Gear Thickness", 30)
z_gear = ui_numberBox("Number of teeth", 30)
show3 = math.floor(ui_scalar('rotate my lobes',0,0,360))

--%%%%%%%%%%% Bore %%%%%%%%%%%%%%%

XY=bore(r_bore,n)
dir_bore = v(0,0,t_gear)
bore = linear_extrude(dir_bore,XY)
--%%%%%%%%%%% Gear %%%%%%%%%%%%%%%

dofile(Path .. './gear.lua') --predefined gear file is called from IceSl library
cpitch = (180*2*R)/(z_gear) -- gear parameters are set according to input parameters of the lobe

numt1 = z_gear
numt2 = z_gear

gear1 = gear{
       number_of_teeth=numt1,
	   circular_pitch=cpitch,
	   gear_thickness=t_gear,
	   rim_thickness=t_gear,
	   circles=0}
gear2 = gear{
       number_of_teeth=numt1,
	   circular_pitch=cpitch,
	   gear_thickness=t_gear,
	   rim_thickness=t_gear,
	   circles=0}
gear0 = translate(0,0,0)*gear1
emit(translate(0,0,-t*1.5)*rotate(0,0,show3)*difference(gear0,bore),1) -- Gear and hole difference is emmitted