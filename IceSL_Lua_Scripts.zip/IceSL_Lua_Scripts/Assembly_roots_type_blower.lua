-- %%%%%% ASSEMBLY %%%%%%

-- With reference to the attached TECHNICAL REPORT and basic gear terminology, following are the additional required variables.

-- r = Rolling circle radius
-- z = Number of lobes
-- n = Number of support points
-- R = Base circle radius
-- Rv = Radius of pump casing
-- a = Center distance
-- t = Impeller thickness
-- XY = Table of vectors
-- t_gear = Gear thickness
-- z_gear = Number of teeth on gear
-- ang_lobe = Angle between lobes
-- Variables: (static_var,dyn_var)

--%%%%%%%%%%% Input %%%%%%%%%%%%%%%
r=ui_numberBox("Rolling circle radius", 15)
z_list = {{2, "2"},{3, "3"},{4, "4"},{5, "5"}}
z = ui_radio("Number of lobes", z_list)
R=2*r*z
a = 2*R
t = ui_numberBox("impeller thickness", 80)
n = 100
dir = v(0,0,t) --direction vector and the thickness in z direction
r_bore = r*z*0.7
r_shaft = r*z*0.7
t_gear=ui_numberBox("Gear Thickness", 30)
z_gear = ui_numberBox("Number of teeth", 30)
len_shaft = ui_numberBox("length of shaft", 136)
show3 = math.floor(ui_scalar('rotate my lobes',0,0,360)) -- for the rendering of the lobes and gear

--%%%%%%%%%%% Lobe %%%%%%%%%%%%%%%
dofile(Path .. './lobes.lua') --used with linear extrude to build a lobe shape. -- This function takes r and z as bore diameter and no. of teeth respectively to calculate the reference lobe profile. The table of vectors XY is output of the function and used to emit shape.
if z%2==0 --if loop used for the positioning of the lobes relative to each other. 
then --for even no. lobes
  emit(translate(-a,0,0)*rotate(0,0,-show3)*lobe,19)
end --end of loop
if z%2~=0 -- for odd no. of lobes
then
  emit(translate(-a,0,0)*rotate(180/z,Z)*rotate(0,0,-show3)*lobe,19) 
end --end of loop

--%%%%%%%%%%% Casing %%%%%%%%%%%%%%%
dofile(Path .. './case.lua') -- This function takes r and n to calculate the casing profile. The table of vectors XY is output of the function and used to emit shape.

--%%%%%%%%%%% Shaft %%%%%%%%%%%%%%%
dofile(Path .. './shafts.lua') -- This function takes r_shaft and n as bore diameter and support points respectively to calculate the shaft. The table of vectors XY is output of the function and used to emit shape.

--%%%%%%%%%%% Gear %%%%%%%%%%%%%%%
dofile(Path .. './backgears.lua') --predefined gear file is called from IceSl library cpitch = (180*2*R)/(z_gear) -- gear parameters are set according to input parameters of the lobe

if numt2 % 2 == 0 then --to adjust the position of two meshing gears
  gear1 = rotate(0,0,0.5*360/numt2)*gear2
end
emit(translate(-2*R,0,-t*1.5)*rotate(0,0,-show3)*gear1,1) 
